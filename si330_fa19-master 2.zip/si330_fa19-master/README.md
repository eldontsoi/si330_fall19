# si330_fa11

Lecture on computational narrative here: https://docs.google.com/presentation/d/1h8SD6uxhvv1qakpL0_3oiiLMXhkrUaZYNgxT37hMgEs/edit?usp=sharing